namespace TodoList.Models;
using TodoList.Models.Entities;

public class TodoViewModel
{
    public IEnumerable<Todo>? Todos { get; set;}


}
